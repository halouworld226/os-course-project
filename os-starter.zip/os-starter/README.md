# OS Course Project — Parallel Images

第 3 版四人交接源码。核心服务、图像处理、共享四进程池、优先级调度、故障恢复和 inode 磁盘镜像使用 C++17，网页和测试使用 Python 3 标准库。

## 构建

需要 Python 3.9+ 和支持 C++17 的 g++。解压后在本目录执行，Windows 可使用 `python`。

```bash
python3 build.py --test
```

该命令直接调用编译器并运行测试，无需 Make/Ninja。Windows 使用 UCRT MinGW g++。常规 CMake 工程也可用，需要已安装的生成器。Linux 实机验收加 `--tcp` 运行真实网络测试。

## 网页演示

```bash
python3 web.py --server ./build/os_server --data demo-data-v3
```

Windows 将可执行文件改成 `build/os_server.exe`。打开 `http://127.0.0.1:8000`，演示账号为 alice、bob、admin，密码均为 demo123。普通用户查看自己的作业，管理员查看全局队列并终止忙进程。默认通过常驻管道会话调用同一个 C++ 服务，异步提交并实时读取状态。

生成一张可上传的样图：

```bash
python3 client.py sample sample.ppm
```

输入支持 P6 PPM、255 最大通道值，宽高各限 1–2048。灰度和反色都有独立串行参考校验。为方便观察，可以设置环境变量 `OS_DEMO_DELAY_MS=300` 后启动服务，每图块延迟 300 毫秒。范围为 0–2000，默认 0。性能测试关闭延迟并记录环境与参数。PowerShell 使用 `$env:OS_DEMO_DELAY_MS='300'`，演示后运行 `Remove-Item Env:OS_DEMO_DELAY_MS`。

## TCP 模式

分别在两个终端启动核心服务和网页桥接：

```bash
./build/os_server 8080 demo-data-v3
python3 web.py --port 8080 --data web-data-v3
```

命令行提交后会打印作业号，替换下列 JOB_ID 即可查询和下载。

```bash
python3 client.py --user alice submit sample.ppm --operation invert --priority high --fault-once
python3 client.py --user alice status JOB_ID
python3 client.py --user alice download JOB_ID inverted.ppm
```

## 接口与代码

TCP 每个请求必须先发送 `AUTH username password` 行。标准输入输出开发入口允许省略 AUTH，并视作本机管理员。所有入口都用于本地课程演示。预置账号密码使用上述 demo 值。

| 指令 | 行为 |
|---|---|
| `SUBMIT GRAYSCALE` / `SUBMIT INVERT` | 后接图片长度帧，完成后返回作业号 |
| `ENQUEUE GRAYSCALE` / `ENQUEUE INVERT` | 后接图片长度帧，入队后立即返回作业号 |
| 可选 `HIGH` / `FAULT` 标记 | 附在提交指令后，高优先级／实际终止一个 worker |
| `STATUS job_id` / `GET job_id` | 查询真实状态／下载已完成图，仅限本人或管理员 |
| `TILE job_id tile_id` | 获取已提交图块的实际 PPM，仅限本人或管理员 |
| `ACTIVE` / `QUEUES` | 管理员读取全局活动作业／真实有序队列和忙进程 |
| `KILL pid` | 管理员终止属于本池且正在忙的工作进程 |

行以 LF 结束，长度帧为 4 字节大端长度及字节，单帧限 16 MiB。响应为 `OK` 或 `ERR` 行加长度帧。每个 TCP 连接处理一次请求，最多同时处理 8 个连接和 8 个在途作业。

图块为 64×64，边缘使用实际尺寸。灰度取 `(299R+587G+114B+500)/1000` 整数值，反色取 `255-value`。四个常驻 worker 通过匿名管道通信。高优先级优先，同级 FIFO，正在运行的图块继续完成。退出图块以原优先级重排，每块最多三次尝试。先成功写入图块，再计入完成数和最终图一次。

| 文件 | 接手范围 |
|---|---|
| `src/job_scheduler.*`、`src/worker.*` | 进程、通信、共享队列和重派 |
| `src/inode_fs.*`、`src/storage.*` | inode 镜像、目录、分配、持久化和回收 |
| `src/server.cpp`、`src/net.*` | 身份、归属权限、异步服务和 TCP |
| `web.py`、`static/` | 网页、实时画布、时间线和演示 |
| `src/image.*`、`tests/` | 两种操作、边缘处理和串行校验 |

镜像位于 `DATA_DIR/disk.img`，默认 128 MiB。原图、描述、归属、已完成图块和最终图均在镜像内。完成标记最后写入，失败作业回收空间。v1/v2 普通目录历史尚无导入工具，请用新数据目录。存储细节见 `STORAGE.md`，网页细节见 `WEB.md`。

## 队友验收

在 Linux 运行 `python3 build.py --test --tcp`，用两个浏览器会话分别登录 alice、bob，提交普通和高优先级作业，再用管理员终止忙 worker。核对队列、事件、实际图块像素和最终结果，重启后下载已完成作业。当前已验证范围见 `CHECKPOINT.md`。服务器异常退出后的未完成作业续算、LRU 缓存和整盘备份可作为后续拓展。
